from django.contrib import admin

from firstapp.models import Curriculum
from django.contrib import admin
# Register your models here.
admin.site.register(Curriculum)